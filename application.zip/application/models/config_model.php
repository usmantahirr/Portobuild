<?php

if (!defined('BASEPATH'))
  exit('No direct script access allowed');

/**
 * Copyright (c) 2012, Aaron Benson - GalleryCMS - http://www.gallerycms.com
 * 
 * GalleryCMS is a free software application built on the CodeIgniter framework. 
 * The GalleryCMS application is licensed under the MIT License.
 * The CodeIgniter framework is licensed separately.
 * The CodeIgniter framework license is packaged in this application (license.txt) 
 * or read http://codeigniter.com/user_guide/license.html
 * 
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 * 
 */
class Config_model extends MY_Model
{
  public function __construct()
  {
    parent::__construct();
    $this->table_name = 'album_config';
  }
  
  /**
   * Get config by album id.
   * 
   * @param type $album_id
   * @return type 
   */
  public function get_by_album_id($album_id)
  {
    $this->db->select('*')
             ->from($this->table_name)
             ->where('album_id', $album_id);
    $q = $this->db->get();
    
    return $q->row();
  }
  
  /**
   * Update config by album id.
   * 
   * @param array $data
   * @param type $album_id
   * @return type 
   */
  public function update_by_album_id(array $data, $album_id)
  {
    $this->db->update($this->table_name, $data, array('album_id' => $album_id));
    
    return $album_id;
  }
  
  /**
   * Delete config by album id.
   * 
   * @param type $album_id
   * @return type 
   */
  public function delete_by_album_id($album_id)
  {
    $this->db->delete($this->table_name, array('album_id' => $album_id));
    
    return $album_id;
  }
}
