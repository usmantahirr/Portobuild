<!doctype html>
<html class="no-js" lang="en">
<?php $this->load->view('header.php');?>
    
        
        <section class="index">
            <div class="heroUnit">
                <div class="title">Portfolio Design</div>
                <div class="subtitle">The Visual Way</div>
                <div class="bannerImage">
                    <img src="<?php echo base_url(); ?>images/homePage/homeBanner.png" alt="Banner Image">
                </div>
            </div>
        </section>
    </body>
</html>