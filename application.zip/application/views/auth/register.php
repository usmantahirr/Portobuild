
<html>
<h1> This page is shown when user has successfuly Registered!</h1>
</html>