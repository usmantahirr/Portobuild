<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title><?php echo $this->config->item('site_title'); ?></title>
        <link rel="stylesheet" href="<?php echo base_url(); ?>_lib/bootstrap/css/bootstrap.css" />
        <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
        <link type="text/css" rel="stylesheet" media="all" href="<?php echo base_url(); ?>css/chat.css" />
        <link type="text/css" rel="stylesheet" media="all" href="<?php echo base_url(); ?>css/screen.css" />
        <script type="text/javascript" src="<?php echo base_url(); ?>js/chat.js"></script>
       
        <link rel="stylesheet" href="<?php echo base_url(); ?>css/admin-style.css">
        <link rel="shortcut icon" href="<?php echo base_url(); ?>images/favicon.ico">

    </head>