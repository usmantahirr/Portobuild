<?php header("Content-type: text/css; charset: UTF-8"); 
?>

h1 {
    color: orange;
    text-align: center;		
}